const http = require('http');
const fs = require('fs');

const new_connection = function(req, res){
	console.log(`New connection from ${req.connection.remoteAddress} for ${req.url}`);
	let myReadStream = fs.createReadStream('data/helloworld.html',"utf8");
	let message = "";
	myReadStream.on("data", function(chunk){
		message += chunk;
	});
	myReadStream.on("end", function(){
		res.writeHead(200, {'Content-Type':'text/html'});
		res.end(message);
	});
};

let server = http.createServer(new_connection);


server.listen(3000, 'localhost');
console.log("The server is now listening on port 3000");
