const http = require('http');
const fs = require('fs');

const new_connection = function(req, res){
	console.log(`New connection from ${req.connection.remoteAddress} for ${req.url}`);
	let myReadStream = fs.createReadStream('data/helloworld.html',"utf8");
	myReadStream.pipe(res);
	
};

let server = http.createServer(new_connection);


server.listen(3000, 'localhost');
console.log("The server is now listening on port 3000");
