const fs = require('fs');
let myReadStream = fs.createReadStream('data/jobs.json',"utf8");

let json_data = "";

myReadStream.on("data", function(chunk) {
	json_data += chunk;
});
myReadStream.on("end", function(chunk) {
	let jobs = JSON.parse(json_data);
	console.log(jobs[0].title);
	console.log(jobs[0].url);
});

