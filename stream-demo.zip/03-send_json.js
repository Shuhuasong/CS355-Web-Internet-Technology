const http = require('http');
const fs = require('fs');

const data = [{'cars':4},{'toupe':false, monacle:2},{'giraffes':'spot'}];

const new_connection = function(req, res){
	console.log(`New connection from ${req.connection.remoteAddress} for ${req.url}`);
	res.writeHead(200,{'Content-Type':'application/json'});
	res.end(JSON.stringify(data));
};

let server = http.createServer(new_connection);

server.listen(3000, 'localhost');
console.log("The server is now listening on port 3000");
